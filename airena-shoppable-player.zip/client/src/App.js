import React from 'react';
import Player from './Player';

function App() {
  return (
    <div>
      <h1>Airena Shoppable Player</h1>
      <Player />
    </div>
  );
}

export default App;
